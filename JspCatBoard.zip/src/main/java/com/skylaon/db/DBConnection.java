package com.skylaon.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	private static Connection con;
	private DBConnection() {}
	
	static public Connection getConnection() throws Exception {
		if(con == null || con.isClosed()) {
			connectDB();
		}
		return con;
		
	}
	
	private static void connectDB() throws Exception{
		String driver = "com.mysql.cj.jdbc.Driver";
		Class.forName(driver);
		
		String url = "jdbc:mysql://localhost:3306/my_board";
		String db_id = "root";
		String db_pw = "root";
		
		con = DriverManager.getConnection(url, db_id, db_pw);
		System.out.println("DB Connection OK");
	}
}

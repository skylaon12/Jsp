package com.skylaon.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class MemberDao extends Da {
	
	// 로그인
	public boolean login(String id, String pw) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		sb.append("select count(*) from " + TABLE_SL_MEMBER);
		sb.append(" where u_id = ? and u_pw = ?;");
		
		pst = con.prepareStatement(toSql());
		
		int valueIndex = 1;
		pst.setString(valueIndex++, id);
		pst.setString(valueIndex++, pw);
		
		ResultSet res = pst.executeQuery();
		
		res.next();
		
		int count = res.getInt("count(*)");
		super.closeConnection(con, pst, res);
		if(count == 1) {
			return true;
		}else {
			return false;
		}
	}
	
	public void register(MemberDto d) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		// 나이 계산
		LocalDate now = LocalDate.now();
		int age = now.getYear() - Integer.parseInt(d.age);
		
		sb.append("insert into " + TABLE_SL_MEMBER);
		sb.append(" values(?, ?, ?, ?, ?);");
		
		pst = con.prepareStatement(toSql());
		
		int valueIndex = 1;
		
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.pw);
		pst.setString(valueIndex++, d.name);
		pst.setInt(valueIndex++, age);
		pst.setString(valueIndex++, d.gender);
		
		int result = pst.executeUpdate();
		
		if(result == 1) {
			System.out.println("회원가입이 완료되었습니다.");
		}else {
			System.out.println("오류가 발생하였습니다.");
		}
		
	}
}

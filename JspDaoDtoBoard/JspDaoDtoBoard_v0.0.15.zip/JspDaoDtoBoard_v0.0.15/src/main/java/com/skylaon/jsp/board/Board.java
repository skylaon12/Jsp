package com.skylaon.jsp.board;

public class Board {
	static public final int LIST_AMOUNT = 4;		// 하나의 리스트에 보일 글 수
	static public final int PAGE_LINK_AMOUNT = 2;	// 페이지 링크 한 블럭에 보일 페이지 링크 개수
	
	// table
	public static final String TABLE_SL_BOARD_FREE = "SL_BOARD_FREE";
	
	int totalPage = 0;	//전체 페이지 수.	🐇페이징🐇
	//페이징 블럭(페이징 처리랑 다 같이)
	
	//전체 페이지 수 구해서 저장해두기
	
	
	//검색
	
}

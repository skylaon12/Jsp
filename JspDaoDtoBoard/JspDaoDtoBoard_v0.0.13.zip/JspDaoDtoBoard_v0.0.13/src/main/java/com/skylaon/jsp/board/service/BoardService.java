package com.skylaon.jsp.board.service;

import com.skylaon.jsp.board.BoardListProcessor;
import com.skylaon.jsp.board.dao.BoardDao;
import com.skylaon.jsp.board.dto.BoardDto;

public class BoardService {
	BoardDao dao;
	
	public BoardService() {
		dao = new BoardDao();
	}
	
	public void del(String no) throws Exception{
		dao.del(no);
	}

	public BoardDto read(String no) throws Exception{
		return dao.selectPost(no); 
	}
	
	public void write(BoardDto d) throws Exception{
		dao.insert(d);
	}
	
	public BoardListProcessor list(String currentPage)throws Exception{
		if(currentPage == null) {
			currentPage = "1";
		}
		BoardListProcessor blp = new BoardListProcessor(dao, currentPage);
		return blp;
	}
	
	public void edit(BoardDto d, String no) throws Exception{
		dao.edit(d, no);
	}
}

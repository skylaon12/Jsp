package com.skylaon.db;

import java.io.IOException;
import java.io.PrintWriter;

import com.skylaon.c.util.Cw;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;

@WebServlet("/member/*")
public class ServletMemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String id = null;
	String pw = null;
	MemberDao dao;
	MemberDto dto;
	PrintWriter writer;
	HttpSession session;
	public void init() throws ServletException {
		dao = new MemberDao();
		dto = new MemberDto();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getPathInfo();
		Cw.wn("action:" + action);
		String nextPage = "/index.jsp";
		if (action != null) {
			switch (action) {

			case "/login_proc":

				id = request.getParameter("id");
				pw = request.getParameter("pw");
				try {
					if (id == null || pw == null) {
						response.setContentType("text/html; charset=UTF-8");
						writer = response.getWriter();
						writer.println("<script>alert('아이디 또는 비밀번호가 공백입니다.'); location.href='"+nextPage+"';</script>");
						writer.close();
					} else {
						dto = dao.login(id, pw);

						if (dto != null) {
							nextPage = "/board/list";
							// 세션에 유저 정보 등록
							session = request.getSession();
							session.setAttribute("user", dto);
							RequestDispatcher d = request.getRequestDispatcher(nextPage);
							d.forward(request, response);
							return;
						} else {
							response.setContentType("text/html; charset=UTF-8");
							writer = response.getWriter();
							writer.println("<script>alert('아이디 또는 비밀번호를 다시 확인해주십시오.'); location.href='"+nextPage+"';</script>");
							writer.close();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "/logout_proc":
				session.invalidate();
				response.setContentType("text/html; charset=UTF-8");
				nextPage = "../index.jsp";
				writer = response.getWriter();
				writer.println("<script>alert('정상적으로 로그아웃 되었습니다.'); location.href='"+nextPage+"';</script>"); 
				writer.close();
				break;
			case "/non_login_proc":
				session = request.getSession();
				session.setAttribute("user", null);
				nextPage = "/board/list";
				response.sendRedirect(nextPage);
				break;
			case "/register_proc":
				id = request.getParameter("new_id");
				pw = request.getParameter("new_pw");
				String pw_re = request.getParameter("pw_re");
				String name = request.getParameter("name");
				String bir = request.getParameter("bir");
				String gender = request.getParameter("gender");
				int isvalid = 0;
				
				if(id.length() < 4 || id.length() > 12 || pw.length() < 4 || pw.length() > 12 || !pw.equals(pw_re) || name == null || bir == null){
					response.setContentType("text/html; charset=UTF-8");
					writer = response.getWriter();
					writer.println("<script>alert('양식에 맞지 않습니다. 다시 확인해주십시오.'); location.href='" + nextPage + "';</script>");
					writer.close();
				}else {
					bir = bir.substring(0, 4);
					isvalid = 1;
				}
				
				if(isvalid == 1){
					MemberDto dto = new MemberDto(id,pw,name,bir,gender);
					MemberDao dao = new MemberDao();
					try {
						dao.register(dto);
					}catch(Exception e) {
						e.printStackTrace();
					}
					response.setContentType("text/html; charset=UTF-8");
					writer = response.getWriter();
					writer.println("<script>alert('회원가입이 완료되었습니다.'); location.href='"+nextPage+"';</script>"); 
					writer.close();
					
				}
				break;
			}
		}

	}

}

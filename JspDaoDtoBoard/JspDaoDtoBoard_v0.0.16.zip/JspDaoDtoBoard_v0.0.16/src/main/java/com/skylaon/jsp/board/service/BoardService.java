package com.skylaon.jsp.board.service;

import com.skylaon.jsp.board.BoardListProcessor;
import com.skylaon.jsp.board.dao.BoardDao;
import com.skylaon.jsp.board.dto.BoardDto;

public class BoardService {
	BoardDao dao;
	
	public BoardService() {
		dao = new BoardDao();
	}
	
	public void del(String category, String no) throws Exception{
		dao.del(category, no);
	}

	public BoardDto read(String category, String no) throws Exception{
		return dao.selectPost(category, no); 
	}
	
	public void write(BoardDto d) throws Exception{
		dao.insert(d);
	}
	
	public BoardListProcessor list(String category, String currentPage, String word)throws Exception{
		if(currentPage == null) {
			currentPage = "1";
		}
		BoardListProcessor blp = new BoardListProcessor(dao, category, currentPage, word);
		return blp;
	}
	
	public void edit(BoardDto d, String no) throws Exception{
		dao.edit(d, no);
	}
}

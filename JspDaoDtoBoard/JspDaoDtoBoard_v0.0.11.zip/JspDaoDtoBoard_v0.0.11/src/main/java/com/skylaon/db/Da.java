package com.skylaon.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Da {

	private static Connection con;

	public static final String TABLE_SL_BOARD_FREE = "SL_BOARD_FREE";
	public static final String TABLE_SL_MEMBER = "SL_MEMBER";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/my_board";
	public static final String DB_ID = "root";
	public static final String DB_PW = "root";
	
	protected static StringBuilder sb = new StringBuilder();
	
	// stringbuilder를 리턴하면서 초기화해줌
	protected static String toSql() {
		String sql = sb.toString();
		sb.setLength(0);
		return sql;
	}
	
	public static Connection getConnection(){
		try {
			if (con == null || con.isClosed())
				connectDB();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return con;
	}

	private static void connectDB() {
		try {
			String driver = "com.mysql.cj.jdbc.Driver";
			Class.forName(driver);
			con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static public void dbExecuteUpdate(String sql){
		Connection con = getConnection();
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement(sql);
			
			int result = pst.executeUpdate();
			
			if (result >= 1) {
				con.commit();
			}else {
				con.rollback();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public static void closeConnection(Connection con) {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(Connection con, PreparedStatement pst) {
		try {
			if (pst != null)
				pst.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(PreparedStatement pst, ResultSet res) {
		try {
			if (res != null)
				res.close();
			if (pst != null)
				pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(Connection con, PreparedStatement pst, ResultSet res) {
		try {
			if (res != null)
				res.close();
			if (pst != null)
				pst.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

package com.skylaon.db;
// 현재 오류나서 못하는중...
// nullpointerException
// 원인 찾는중...
public class MemberService {
	MemberDao dao;
	MemberDto dto;
	
	public MemberService() {
		dao = new MemberDao();
		dto = new MemberDto();
	}
	public MemberDto login(String id, String pw) throws Exception{
		System.out.println("멤버서비스 시작");
		dto = dao.login(id, pw);
		System.out.println("멤버서비스에서 실어옴");
		return dto;
	}
	
	public void register(MemberDto d) throws Exception{
		dao.register(d);
	}
}

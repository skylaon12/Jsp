package com.skylaon.db;

import java.util.ArrayList;

public class BoardService {
	BoardDao dao;
	
	public BoardService() {
		dao = new BoardDao();
	}
	
	public void del(String no) throws Exception{
		dao.del(no);
	}

	public BoardDto read(String no) throws Exception{
		return dao.read(no); 
	}
	
	public void write(BoardDto d) throws Exception{
		dao.write(d);
	}
	
	public ArrayList<BoardDto> list()throws Exception{
		return dao.list();
	}
	
	public void edit(BoardDto d, String no) throws Exception{
		dao.edit(d, no);
	}
	

	// 총 페이지 수
	public int getTotalPageCount() throws Exception{
		int count = dao.getPostCount();// 게시물 수
		int totalPageCount = 0;

		if(count % Board.LIST_AMOUNT == 0){		//case1. 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / Board.LIST_AMOUNT;
		}else{					//case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	// 총 페이지 수<검색>
	public int getTotalPageCount(String word) throws Exception{
		int count = dao.getPostCount(word); // 게시물 수
		int totalPageCount = 0;

		if(count % Board.LIST_AMOUNT == 0){		//case1. 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / Board.LIST_AMOUNT;
		}else{					//case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
}

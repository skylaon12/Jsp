package com.skylaon.jsp.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.skylaon.db.Dao;
import com.skylaon.jsp.board.Board;
import com.skylaon.jsp.board.dto.BoardDto;

public class BoardDao {

	// 삭제
	public void del(String category, String no) throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		Dao.sb.append("delete from " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append(" where b_no = ? and b_category like ?");
		
		pst = con.prepareStatement(Dao.toSql());
		
		int valueIndex = 1;
		pst.setString(valueIndex++, no);
		pst.setString(valueIndex++, category);
		System.out.println(pst.toString());
		int result = pst.executeUpdate();

		if (result == 1) {
			System.out.println("삭제가 완료되었습니다.");
		} else {
			System.out.println("삭제에 실패하였습니다.");
		}
		Dao.closeConnection(con, pst);
	}

	// 쓰기
	public void insert(BoardDto d) throws Exception {

		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		Dao.sb.append("insert into " + Board.TABLE_SL_BOARD_FREE + " (b_category, b_title, b_id, b_text) ");
		Dao.sb.append("values(?, ?, ?, ?);");

		pst = con.prepareStatement(Dao.toSql());

		int valueIndex = 1;
		
		pst.setString(valueIndex++, d.category);
		pst.setString(valueIndex++, d.title);
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.text);

		int result = pst.executeUpdate();
		if (result == 1) {
			System.out.println("등록이 완료되었습니다.");
		} else {
			System.out.println("등록에 실패하였습니다.");
		}
		Dao.closeConnection(con, pst);

	}

	// 조회수 증가
	public void hitPlus(String no) throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		Dao.sb.append("update " + Board.TABLE_SL_BOARD_FREE + " set b_hit = b_hit + 1 ");
		Dao.sb.append("where b_no = " + no);

		pst = con.prepareStatement(Dao.toSql());

		int result = pst.executeUpdate();

		if (result == 1) {

		} else {

		}

		Dao.closeConnection(con, pst);
	}

	// 읽기
	public BoardDto selectPost(String category, String no) throws Exception {

		hitPlus(no);

		BoardDto post = null;
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		Dao.sb.append("select * from " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append(" where b_no = " + no);

		pst = con.prepareStatement(Dao.toSql());

		ResultSet res = pst.executeQuery();

		if (res.next()) {
			post = new BoardDto(category, res.getString("B_NO"), res.getString("B_TITLE"), res.getString("B_ID"),
					res.getString("B_DATETIME"), res.getString("B_HIT"), res.getString("B_TEXT").replaceAll("\r\n", "</br>"),
					res.getString("B_REPLY_COUNT"), res.getString("B_REPLY_ORI"));
		} else {
			System.out.println("시스템 오류 발생");
		}

		Dao.closeConnection(con, pst, res);

		return post;
	}

	// 리스트
//	public ArrayList<BoardDto> listBackup(String page) throws Exception {
//		ArrayList<BoardDto> posts = new ArrayList<>();
//		Connection con = Dao.getConnection();
//		PreparedStatement pst = null;
//
//		int startIndex = ((Integer.parseInt(page)) - 1) * Board.LIST_AMOUNT;
//
//		String sql = String.format("select * from %s order by b_no desc limit %d,%d", Board.TABLE_SL_BOARD_FREE,
//				startIndex, Board.LIST_AMOUNT);
//
//		pst = con.prepareStatement(sql);
//
//		ResultSet res = pst.executeQuery();
//
//		while (res.next()) {
//			posts.add(new BoardDto(res.getString("B_NO"), res.getString("B_TITLE"), res.getString("B_ID"),
//					res.getString("B_DATETIME"), res.getString("B_HIT"), res.getString("B_TEXT"),
//					res.getString("B_REPLY_COUNT"), res.getString("B_REPLY_ORI")));
//		}
//		Dao.closeConnection(con, pst, res);
//		return posts;
//	}

	// 수정
	public void edit(BoardDto d, String no) throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		Dao.sb.append("update " + Board.TABLE_SL_BOARD_FREE + " set b_title = ?, b_text = ? \n");
		Dao.sb.append("			where b_no = ?");

		pst = con.prepareStatement(Dao.toSql());
		int valueIndex = 1;

		pst.setString(valueIndex++, d.title);
		pst.setString(valueIndex++, d.text);
		pst.setString(valueIndex++, no);

		int result = pst.executeUpdate();

		if (result == 1) {
			System.out.println("수정이 완료되었습니다.");
		} else {
			System.out.println("수정에 실패하였습니다.");
		}
		Dao.closeConnection(con, pst);
	}

	// 게시물 불러오기
	public ArrayList<BoardDto> selectList(String category, int startIndex) {
		ArrayList<BoardDto> posts = new ArrayList<>();
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		try {
			Dao.sb.append("SELECT * FROM " + Board.TABLE_SL_BOARD_FREE);
			Dao.sb.append("			WHERE B_TITLE <> '' AND B_CATEGORY LIKE ?");
			Dao.sb.append(" 		ORDER BY B_NO DESC LIMIT ?, ?;");
			
			pst = con.prepareStatement(Dao.toSql());
			
			int valueIndex = 1;
			pst.setString(valueIndex++, category);
			pst.setInt(valueIndex++, startIndex);
			pst.setInt(valueIndex++, Board.LIST_AMOUNT);
			
			ResultSet res = pst.executeQuery();
			while (res.next()) {
				posts.add(new BoardDto(
									res.getString("B_CATEGORY"),
									res.getString("B_NO"),
									res.getString("B_TITLE"),
									res.getString("B_ID"),
									res.getString("B_DATETIME"),
									res.getString("B_HIT"),
									res.getString("B_TEXT"),
									res.getString("B_REPLY_COUNT"),
									res.getString("B_REPLY_ORI")));
			}
			Dao.closeConnection(con, pst, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return posts;
	}

	// 리스트<검색>
	public ArrayList<BoardDto> selectList(String category, int startIndex, String word) throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		ArrayList<BoardDto> posts = new ArrayList<BoardDto>();
		// 작업 필요 06.26
		Dao.sb.append("SELECT B_CATEGORY, B_NO, B_TITLE, B_ID, B_DATETIME, B_HIT, B_TEXT, B_REPLY_COUNT, B_REPLY_ORI");
		Dao.sb.append(" 	FROM "+ Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append(" 	WHERE B_TITLE LIKE CONCAT('%', ?, '%') AND B_CATEGORY LIKE CONCAT('%', ?, '%')");
		Dao.sb.append(" 	ORDER BY B_NO DESC LIMIT ?, ?");

		pst = con.prepareStatement(Dao.toSql());
		int valueIndex = 1;
		
		
		pst.setString(valueIndex++, word);
		pst.setString(valueIndex++, category);
		pst.setInt(valueIndex++, startIndex);
		pst.setInt(valueIndex++, Board.LIST_AMOUNT);

		ResultSet res = pst.executeQuery();

		while (res.next()) {
			posts.add(new BoardDto(
								res.getString("B_CATEGORY"),
								res.getString("B_NO"),
								res.getString("B_TITLE"),
								res.getString("B_ID"),
								res.getString("B_DATETIME"),
								res.getString("B_HIT"),
								res.getString("B_TEXT"),
								res.getString("B_REPLY_COUNT"),
								res.getString("B_REPLY_ORI")));
		}

		Dao.closeConnection(con, pst, res);
		return posts;
	}

	// 총 개시물 수
	public int getPostCount(String category) throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		String sql = String.format(
				"select count(*) from %s where b_category like '%s'"
				,Board.TABLE_SL_BOARD_FREE, category);

		pst = con.prepareStatement(sql);
		ResultSet res = pst.executeQuery();

		int count = res.next() ? res.getInt("count(*)") : 0;

		Dao.closeConnection(con, pst, res);
		return count;
	}

	// 총 게시물 수<검색용>
	public int getPostCount(String category, String word) throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;

		String sql = String.format("SELECT COUNT(*) FROM %s WHERE B_TITLE LIKE '%%%s%%' AND B_CATEGORY LIKE '%s'"
				, Board.TABLE_SL_BOARD_FREE, word, category);

		pst = con.prepareStatement(sql);
		ResultSet res = pst.executeQuery();

		int count = res.next() ? res.getInt("count(*)") : 0;

		Dao.closeConnection(con, pst, res);
		return count;
	}
	
	// read.jsp에서 해당 게시물에 대한 댓글 정보
	public ArrayList<BoardDto> getReply(String no)throws Exception{
		System.out.println("BoardDao의 no : " + no);
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		ArrayList<BoardDto> re_posts = new ArrayList<>();
		System.out.println("Dao진입");
		Dao.sb.append("SELECT B_ID, B_DATETIME, B_TEXT ");
		Dao.sb.append("FROM " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append("		WHERE B_REPLY_ORI = (SELECT B_NO FROM " +  Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append("								where b_no = " + no + ")");
		
		pst = con.prepareStatement(Dao.toSql());
		
		ResultSet res = pst.executeQuery();
		
		while(res.next()) {
			re_posts.add(new BoardDto(
						res.getString("B_ID"),
						res.getString("B_DATETIME"),
						res.getString("B_TEXT")
						));
		}
		System.out.println(re_posts.size());
		Dao.closeConnection(con, pst, res);
		return re_posts;
	}
	
	// 댓글 등록
	public void setReply(BoardDto d) throws Exception{
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		
		Dao.sb.append("INSERT INTO " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append(" (B_ID, B_TEXT, B_REPLY_ORI, B_CATEGORY) ");
		Dao.sb.append(" VALUES(?, ?, ?, ?);");
		
		pst = con.prepareStatement(Dao.toSql());
		
		int valueIndex = 1;
		
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.text);
		pst.setString(valueIndex++, d.replyOri);
		pst.setString(valueIndex++, d.category);
		
		int result = pst.executeUpdate();
		
		if(result == 1) {
			System.out.println("댓글 작성 완료");
		}else {
			System.out.println("댓글 작성 실패");
		}
	}

	// 댓글의 고유번호(b_no)를 받아서
	// 삭제 작업
	public void reply_del(String no)throws Exception{
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		
		Dao.sb.append("DELETE FROM " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append(" WHERE B_NO = ?");
		
		pst = con.prepareStatement(Dao.toSql());
		
		pst.setString(1, no);
		
		int result = pst.executeUpdate();
		if (result == 1) {
			System.out.println("등록이 완료되었습니다.");
		} else {
			System.out.println("등록에 실패하였습니다.");
		}
			Dao.closeConnection(con, pst);		
	}	
	
}

package com.skylaon.jsp.member;

public class Member {
	public static final String TABLE_SL_MEMBER = "SL_MEMBER";
}

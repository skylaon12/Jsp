package com.skylaon.jsp.member.dto;

public class MemberDto {

	public String id;
	public String pw;
	public String name;
	public String age;
	public String gender;
	
	public MemberDto() {
	}
	public MemberDto(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}
	
	public MemberDto(String id, String name, String age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}

	public MemberDto(String id, String pw, String name, String age, String gender) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	
	
	
}

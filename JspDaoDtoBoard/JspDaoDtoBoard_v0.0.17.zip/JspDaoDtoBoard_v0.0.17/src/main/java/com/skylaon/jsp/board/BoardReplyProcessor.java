package com.skylaon.jsp.board;

import java.util.ArrayList;

import com.skylaon.jsp.board.dao.BoardDao;
import com.skylaon.jsp.board.dto.BoardDto;

public class BoardReplyProcessor {
	private BoardDao dao;
	public ArrayList<BoardDto> re_posts;
	public BoardReplyProcessor(String no) throws Exception{
		dao = new BoardDao();
		getReplys(no);
	}

	
	public void getReplys(String no) throws Exception{
		System.out.println("dao에서 댓글 정보 받기 시도. no : " + no);
		re_posts = dao.getReply(no);
	}
	
	public void setReplys(String id, String text, String no, String category) throws Exception{
		BoardDto d = new BoardDto(id,text,no);
		d.category = category;
		dao.setReply(d);
	}

	// 댓글 화면에 뿌려줘야함.
	public String getHtmlReplyList() {
		String html = "";
		
		for(int i = 0; i < re_posts.size(); i++) {
			html += String.format("<tr><th>%s</th><td>%s</td><td>%s</td></tr>", re_posts.get(i).id, re_posts.get(i).text,re_posts.get(i).datetime);
		}
		
		return html;
	}
}

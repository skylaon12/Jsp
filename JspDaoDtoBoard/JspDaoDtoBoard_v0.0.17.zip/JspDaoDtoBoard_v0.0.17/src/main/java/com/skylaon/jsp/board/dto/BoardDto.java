package com.skylaon.jsp.board.dto;

public class BoardDto {

	public String category;
	public String no;
	public String title;
	public String id;
	public String datetime;
	public String hit;
	public String text;
	public String replyCount;
	public String replyOri;
	
	public BoardDto() {}
	
	public BoardDto(String id) {
		this.id = id;
	}
	
	public BoardDto(String title, String text) {
		this.title = title;
		this.text = text;
	}
	
	public BoardDto(String id, String datetime, String text) {
		this.id = id;
		this.datetime = datetime;
		this.text = text;
	}
	
	public BoardDto(String category, String title, String id, String text) {
		this.category = category;
		this.title = title;
		this.id = id;
		this.text = text;
	}

	public BoardDto(String category, String no, String title, String id, String datetime, String hit, String text, String replyCount, String replyOri) {
		this.category = category;
		this.no = no;
		this.title = title;
		this.id = id;
		this.datetime = datetime;
		this.hit = hit;
		this.text = text;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}

	
	
	
	
	
	
	
}

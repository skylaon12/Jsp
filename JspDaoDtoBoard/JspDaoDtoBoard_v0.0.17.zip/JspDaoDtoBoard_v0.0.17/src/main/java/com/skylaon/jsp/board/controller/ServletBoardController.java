package com.skylaon.jsp.board.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.skylaon.c.util.Cw;
import com.skylaon.jsp.board.BoardListProcessor;
import com.skylaon.jsp.board.BoardReplyProcessor;
import com.skylaon.jsp.board.dao.BoardDao;
import com.skylaon.jsp.board.dto.BoardDto;
import com.skylaon.jsp.board.service.BoardService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/board/*")
public class ServletBoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String category;
	String nextPage;
	BoardDao dao;
	BoardDto dto;
	RequestDispatcher d;
	PrintWriter writer;
	BoardService service;
	@Override
	public void init() throws ServletException {
		dao = new BoardDao();
		dto = new BoardDto();
		service = new BoardService();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		category = request.getParameter("category");
		String action = request.getPathInfo();
		Cw.wn("action:"+action);
		if(action!=null) {
			switch(action) {
			//했음
			case "/del":
				Cw.wn("삭제");
				nextPage="/board/list?category="+category;
				try {
					service.del(category, request.getParameter("no"));
				}catch(Exception e) {
					e.printStackTrace();
				}
				break;
			case "/write"://todo
				Cw.wn("쓰기");
				nextPage="/board/list?category="+category;
				dto = new BoardDto(
						category,
						request.getParameter("title"),
						request.getParameter("id"),
						request.getParameter("text")
						);
				try {
					service.write(dto);
				}catch(Exception e) {
					e.printStackTrace();
				}
				response.setContentType("text/html; charset=UTF-8");
				writer = response.getWriter();
				writer.println("<script>alert('게시글 작성이 완료되었습니다.'); location.href='"+nextPage+"';</script>"); 
				writer.close();
				return;
			case "/edit_insert":
				try {
					Cw.wn("수정-insert");
					nextPage = "../edit.jsp";
					System.out.println(category);
					request.setAttribute("post", service.read(category, request.getParameter("no")));
				}catch(Exception e) {
					e.printStackTrace();
				}
				// 화면만 불러오기 때문에 RequestDispatcher로 처리
				d = request.getRequestDispatcher(nextPage);
				d.forward(request, response);
				return;
			case "/edit_proc"://todo
				Cw.wn("수정-proc");
				String no = request.getParameter("no");
				String title = request.getParameter("title");
				String text = request.getParameter("text");
				nextPage="/board/list?category="+category;
				// 엔터를 <br>로 변환
				text = text.replaceAll("\r\n", "</br>");
				
				try {
					service.edit(
							new BoardDto(title, text)
							, no);
				} catch (Exception e) {
					e.printStackTrace();
				} 
				response.setContentType("text/html; charset=UTF-8");
				writer = response.getWriter();
				writer.println("<script>alert('게시글 수정이 완료되었습니다.'); location.href='"+nextPage+"';</script>"); 
				writer.close();
				return;
			case "/read"://todo
				try {
					BoardReplyProcessor brp = service.getReply(request.getParameter("no"));
					if(brp != null) {
						System.out.println("댓글 불러옴");
						System.out.println(brp.re_posts.size());
						request.setAttribute("replys", brp);
					}
					dto = service.read(category, request.getParameter("no"));
					request.setAttribute("post", dto);
					nextPage="../read.jsp";
				} catch (Exception e) {
					e.printStackTrace();
				}
				// 읽어오기만 하기 때문에 RequestDispatcher로 처리
				d = request.getRequestDispatcher(nextPage);
				d.forward(request, response);
				return; // 리턴으로 함수 끝내기
			case "/list"://todo
				nextPage="/list.jsp";
				try {
					BoardListProcessor blp = service.list(category, request.getParameter("page"),request.getParameter("word"));
					request.setAttribute("blp", blp);
					System.out.println("listservlet 통과");
				}catch (Exception e) {
					System.out.println("list컨트롤러 에러");
					e.printStackTrace();
				}
				d = request.getRequestDispatcher(nextPage);
				System.out.println("디스패쳐로 보내기");
				d.forward(request, response);
				return; // 리턴으로 함수 끝내기
			case "/reply_proc":// 댓글작성시
				nextPage = "/board/read?category="+category+"&no="+request.getParameter("no");
				if(request.getParameter("id").equals("null")) {
					response.setContentType("text/html; charset=UTF-8");
					writer = response.getWriter();
					writer.println("<script>alert('로그인 후 이용가능합니다.'); location.href='"+nextPage+"';</script>"); 
					writer.close();
					return;
				}
				dto = new BoardDto(request.getParameter("id"));
				dto.text = request.getParameter("text");
				dto.replyOri = request.getParameter("no");
				dto.category = category;
				try {
					service.setReply(dto);
				}catch(Exception e) {
					e.printStackTrace();
				}
				break;
			}
			response.sendRedirect(nextPage);
		}
	}
}
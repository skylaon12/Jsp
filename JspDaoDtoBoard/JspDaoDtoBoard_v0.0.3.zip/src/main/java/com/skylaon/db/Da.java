package com.skylaon.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Da {

	private static Connection con;

	public static final String TABLE_SL_BOARD_FREE = "SL_BOARD_FREE";

	public static Connection getConnection() throws Exception {

		if (con == null || con.isClosed())
			connectDB();
		return con;
	}

	private static void connectDB() throws Exception {
		String driver = "com.mysql.cj.jdbc.Driver";
		Class.forName(driver);

		String url = "jdbc:mysql://localhost:3306/my_board";
		String db_id = "root";
		String db_pw = "root";

		con = DriverManager.getConnection(url, db_id, db_pw);
		System.out.println("DB Connection Ok");
	}

	public static void closeConnection(Connection con) {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(Connection con, PreparedStatement pst) {
		try {
			if (con != null)
				con.close();
			if (pst != null)
				pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(PreparedStatement pst, ResultSet res) {
		try {
			if (res != null)
				res.close();
			if (pst != null)
				pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void closeConnection(Connection con, PreparedStatement pst, ResultSet res) {
		try {
			if (con != null)
				con.close();
			if (res != null)
				res.close();
			if (pst != null)
				pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

package com.skylaon.db;

import java.io.IOException;

import com.skylaon.c.util.Cw;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/board/*")
public class ServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String nextPage;
	BoardDao dao;
	BoardDto dto;
	RequestDispatcher d;
	@Override
	public void init() throws ServletException {
		dao = new BoardDao();
		dto = new BoardDto();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getPathInfo();
		Cw.wn("action:"+action);
		if(action!=null) {
			switch(action) {
			//했음
			case "/del":
				Cw.wn("삭제");
				nextPage="../list.jsp";
				try {
					dao.del(request.getParameter("no"));
				}catch(Exception e) {
					e.printStackTrace();
				}
				break;
			case "/write"://todo
				Cw.wn("쓰기");
				nextPage="../list.jsp";
				dto = new BoardDto(
						request.getParameter("title"),
						request.getParameter("id"),
						request.getParameter("text")
						);
				try {
					dao.write(dto);
				}catch(Exception e) {
					e.printStackTrace();
				}
				break;
			case "/edit_insert":
				try {
					Cw.wn("수정-insert");
					nextPage = "../edit.jsp";
					request.setAttribute("post", dao.read(request.getParameter("no")));
				}catch(Exception e) {
					e.printStackTrace();
				}
				// 화면만 불러오기 때문에 RequestDispatcher로 처리
				d = request.getRequestDispatcher(nextPage);
				d.forward(request, response);
				return;
			case "/edit_proc"://todo
				Cw.wn("수정-proc");
				String no = request.getParameter("no");
				String title = request.getParameter("title");
				String text = request.getParameter("text");
				// 엔터를 <br>로 변환
				text = text.replaceAll("\r\n", "</br>");
				
				try {
					dao.edit(
							new BoardDto(title, text)
							, no);
				} catch (Exception e) {
					e.printStackTrace();
				} 
				
				nextPage="../list.jsp";
				break;
			case "/read"://todo
				try {
					Cw.wn("읽기 서블릿진입");
					dto = dao.read(request.getParameter("no"));
					request.setAttribute("post", dto);
					nextPage="../read.jsp";
				} catch (Exception e) {
					e.printStackTrace();
				}
				// 읽어오기만 하기 때문에 RequestDispatcher로 처리
				d = request.getRequestDispatcher(nextPage);
				d.forward(request, response);
				return; // 리턴으로 함수 끝내기
			case "/list"://todo
				Cw.wn("서블릿리스트");
				nextPage="../list.jsp";
				break;
			}
			response.sendRedirect(nextPage);
		}
	}
}
package com.skylaon.db;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletEdit
 */
@WebServlet("/ServletEdit")
public class ServletEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String no = request.getParameter("no");
		String title = request.getParameter("title");
		String text = request.getParameter("text");
		text = text.replaceAll("\r\n", "</br>");
		
		BoardDao dao = new BoardDao();
		BoardDto dto = new BoardDto(title,text);
		try {
			dao.edit(dto, no);
		}catch(Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("list.jsp");
	}

}

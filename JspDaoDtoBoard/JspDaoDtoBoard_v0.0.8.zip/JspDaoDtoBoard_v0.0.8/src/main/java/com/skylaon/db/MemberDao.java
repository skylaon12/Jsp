package com.skylaon.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class MemberDao extends Da {
	
	// 로그인
	public MemberDto login(String id, String pw) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		MemberDto dto = null;
		
		sb.append("select U_ID, U_NAME, U_AGE from " + TABLE_SL_MEMBER);
		sb.append(" where U_ID = ? and U_PW = ?;");
		
		pst = con.prepareStatement(toSql());
		
		int valueIndex = 1;
		pst.setString(valueIndex++, id);
		pst.setString(valueIndex++, pw);
		
		ResultSet res = pst.executeQuery();
		
		if(res.next()) {
			// id, name, age 받아서 dto객체 초기화로 만들어서 담아서 리턴
			dto = new MemberDto(
					res.getString("u_id"),
					res.getString("u_name"),
					res.getString("u_age")
					);
		}
		return dto;
	}
	
	
	
	public void register(MemberDto d) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		// 나이 계산
		LocalDate now = LocalDate.now();
		int age = now.getYear() - Integer.parseInt(d.age);
		
		sb.append("insert into " + TABLE_SL_MEMBER);
		sb.append(" values(?, ?, ?, ?, ?);");
		
		pst = con.prepareStatement(toSql());
		
		int valueIndex = 1;
		
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.pw);
		pst.setString(valueIndex++, d.name);
		pst.setInt(valueIndex++, age);
		pst.setString(valueIndex++, d.gender);
		
		int result = pst.executeUpdate();
		
		if(result == 1) {
			System.out.println("회원가입이 완료되었습니다.");
		}else {
			System.out.println("오류가 발생하였습니다.");
		}
		
	}
}

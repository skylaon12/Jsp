package com.skylaon.jsp.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

import com.skylaon.db.Dao;
import com.skylaon.jsp.member.Member;
import com.skylaon.jsp.member.dto.MemberDto;

public class MemberDao {
	
	// 로그인
	public MemberDto login(String id, String pw) throws Exception{
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		MemberDto dto = null;
		
		Dao.sb.append("select U_ID, U_NAME, U_AGE from " + Member.TABLE_SL_MEMBER);
		Dao.sb.append(" where U_ID = ? and U_PW = ?;");
		
		pst = con.prepareStatement(Dao.toSql());
		
		int valueIndex = 1;
		pst.setString(valueIndex++, id);
		pst.setString(valueIndex++, pw);
		
		ResultSet res = pst.executeQuery();
		
		if(res.next()) {
			// id, name, age 받아서 dto객체 초기화로 만들어서 담아서 리턴
			dto = new MemberDto(
					res.getString("u_id"),
					res.getString("u_name"),
					res.getString("u_age")
					);
		}
		return dto;
	}
	
	
	
	public void register(MemberDto d) throws Exception{
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		
		// 나이 계산
		LocalDate now = LocalDate.now();
		int age = now.getYear() - Integer.parseInt(d.age);
		
		Dao.sb.append("insert into " + Member.TABLE_SL_MEMBER);
		Dao.sb.append(" values(?, ?, ?, ?, ?);");
		
		pst = con.prepareStatement(Dao.toSql());
		
		int valueIndex = 1;
		
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.pw);
		pst.setString(valueIndex++, d.name);
		pst.setInt(valueIndex++, age);
		pst.setString(valueIndex++, d.gender);
		
		int result = pst.executeUpdate();
		
		if(result == 1) {
			System.out.println("회원가입이 완료되었습니다.");
		}else {
			System.out.println("오류가 발생하였습니다.");
		}
		
	}
	
}

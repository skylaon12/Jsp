package com.skylaon.jsp.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.skylaon.db.Dao;
import com.skylaon.jsp.board.Board;
import com.skylaon.jsp.board.dto.BoardDto;

public class ReplyDao {
	
	// 댓글 등록
	// ui상에서 작성하는 댓글 정보(댓글 삭성자 id, 댓글내용, 원글번호, 원글 카테고리)를 받아서 
	// db에 저장
	public void reply_reg(BoardDto d)throws Exception {
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		
		Dao.sb.append("ISNERT INTO " + Board.TABLE_SL_BOARD_FREE + " (B_ID, B_TEXT, B_REPLY_ORI, B_CATEGORY) ");
		Dao.sb.append("values(?, ?, ?, ?)");
		
		pst = con.prepareStatement(Dao.toSql());
		
		int valueIndex = 1;
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.text);
		pst.setString(valueIndex++, d.replyOri);
		pst.setString(valueIndex++, d.category);
		
		int result = pst.executeUpdate();
		if (result == 1) {
			System.out.println("등록이 완료되었습니다.");
		} else {
			System.out.println("등록에 실패하였습니다.");
		}
		Dao.closeConnection(con, pst);		
	}
	
	// 댓글 정보
	// 원글의 b_no를 받아서 DB에서 b_reply_ori랑 비교해서 같은 것들은
	// dto 객체배열에 담아서 return
	public ArrayList<BoardDto> reply_info(String no)throws Exception{
		
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		ArrayList<BoardDto> replys = new ArrayList<>();
		
		Dao.sb.append("SELECT B_ID, B_TEXT, B_DATETIME ");
		Dao.sb.append("FROM " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append("			WHERE B_REPLY_ORI = ? ");
		
		pst = con.prepareStatement(Dao.toSql());
		pst.setString(1, no);
		
		ResultSet res = pst.executeQuery(); 
		
		while(res.next()) {
			replys.add(new BoardDto(
						res.getString("B_ID"),
						res.getString("B_TEXT"),
						res.getString("B_DATETIME")
					));
		}
		Dao.closeConnection(con, pst, res);
		return replys;
	}
	
	// 댓글의 고유번호(b_no)를 받아서
	// 삭제 작업
	public void reply_del(String no)throws Exception{
		Connection con = Dao.getConnection();
		PreparedStatement pst = null;
		
		Dao.sb.append("DELETE FROM " + Board.TABLE_SL_BOARD_FREE);
		Dao.sb.append(" WHERE B_NO = ?");
		
		pst = con.prepareStatement(Dao.toSql());
		
		pst.setString(1, no);
		
		int result = pst.executeUpdate();
		if (result == 1) {
			System.out.println("등록이 완료되었습니다.");
		} else {
			System.out.println("등록에 실패하였습니다.");
		}
		Dao.closeConnection(con, pst);		
	}

}

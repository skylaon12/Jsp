package com.skylaon.db;

public class Db {
	public static final String DB_URL = "jdbc:mysql://localhost:3306/my_board";
	public static final String DB_ID = "root";
	public static final String DB_PW = "root";
}

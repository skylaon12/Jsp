package com.skylaon.jsp.board;

import java.util.ArrayList;

import com.skylaon.jsp.board.dao.BoardDao;
import com.skylaon.jsp.board.dto.BoardDto;

public class BoardListProcessor {

	private BoardDao dao;
	public ArrayList<BoardDto> posts;
	public int totalPage = 0;	// 전체페이지 수
	public int currentPage = 0; // 현재 페이지 번호
	
	//{블럭 처리 - 1/9}.블럭 총 갯수 구하기//
	int totalBlock = 0;
	//{블럭 처리 - 2/9}.현재 블럭 번호 구하기//
	int currentBlockNo = 0;
	//{블럭 처리 - 3/9}.블럭 시작 페이지 번호 구하기
	int blockStartNo = 0;
	//{블럭 처리 - 4/9}.블럭 끝 페이지 번호 구하기
	int blockEndNo = 0;
	//{블럭 처리 - 5/9}.(이전/다음) 관련 초기화 처리
	int prevPage = 0;
	int nextPage = 0;
	//{블럭 처리 - 6/9}.(이전/다음) 관련 계산 등 처리
	boolean hasPrev = true;
	boolean hasNext = true;
	
	public BoardListProcessor(BoardDao dao, String currentPage) throws Exception{
		super();
		this.dao = dao;
		this.currentPage = Integer.parseInt(currentPage);
		this.totalPage = getTotalPageCount();
		// todo
		// 현재 페이지 번호와 전체 페이지 수를 기반으로
		getList();	// 리스트 데이터 얻어오기
		
		// 총 블럭 수 = 전체 페이지 / 블럭 당 페이지 수 (올림)
		totalBlock = (int)Math.ceil((double)totalPage/Board.PAGE_LINK_AMOUNT);
		// 현재 블럭 번호 = 현재 페이지 / 블럭 당 페이지 수 (올림)
		currentBlockNo = (int)Math.ceil((double)this.currentPage/Board.PAGE_LINK_AMOUNT);
		// 블럭 시작 페이지 번호 = (현재 블럭 번호 -1) * 블럭 당 페이지 수 + 1 
		blockStartNo = (currentBlockNo - 1) * Board.PAGE_LINK_AMOUNT + 1;
		// 블럭 끝 페이지 번호 = 현재 블럭 번호 * 블럭 당 페이지 수
		// 블럭끝페이지번호 = 블럭끝페이지번호>전체페이지수)?전체페이지수:블럭끝페이지번호
		blockEndNo = currentBlockNo * Board.PAGE_LINK_AMOUNT;
		if(blockEndNo > totalPage) {
			blockEndNo = totalPage;
		}
		
		// (이전/다음) 관련 계산
		// 현재 블럭에서 이전/다음 가능 여부 확인
		if(currentBlockNo == 1) {	// 현재 블럭이 1이면
			hasPrev = false;	// 이전 블럭 비활성화
		}else {
			hasPrev = true;		// 이전 블럭 활성화
			// 이전 블럭 이동 시 몇 페이지로 이동할지 정하기
			// 이전 블럭의 마지막 페이지로 이동하게 하면 된다.
			prevPage = (currentBlockNo - 1) * Board.PAGE_LINK_AMOUNT;
		}
		if(currentBlockNo < totalBlock) {
			hasNext = true;
			// 다음 블럭 이동 시 몇 페이지로 이동할지 정하기
			// 다음 블럭의 첫 페이지로 이동하게 하면 된다.
			nextPage = currentBlockNo * Board.PAGE_LINK_AMOUNT + 1;
		}else {
			hasNext = false;
		}
	}
	
	public void getList() {
		// 시작 인덱스 계산해서 넘기기
		int startIndex = (currentPage-1)*Board.LIST_AMOUNT;
		posts = dao.selectList(startIndex);
		// todo test 안함
	}
	
	// 총 페이지 수
		public int getTotalPageCount() throws Exception{
			int count = dao.getPostCount();// 게시물 수
			int totalPageCount = 0;

			if(count % Board.LIST_AMOUNT == 0){		//case1. 나머지가 없이 딱 떨어지는 경우
				totalPageCount = count / Board.LIST_AMOUNT;
			}else{					//case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
				totalPageCount = count / Board.LIST_AMOUNT + 1;
			}
			return totalPageCount;
		}
		
		// 총 페이지 수<검색>
		public int getTotalPageCount(String word) throws Exception{
			int count = dao.getPostCount(word); // 게시물 수
			int totalPageCount = 0;

			if(count % Board.LIST_AMOUNT == 0){		//case1. 나머지가 없이 딱 떨어지는 경우
				totalPageCount = count / Board.LIST_AMOUNT;
			}else{					//case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
				totalPageCount = count / Board.LIST_AMOUNT + 1;
			}
			return totalPageCount;
		}
		
		// 글 리스트 객체 얻는 함수
		public ArrayList<BoardDto> getPosts(){
			return posts;
		}
		
		// 페이지 리스트들을 출력하기 위한 html을 리턴
		public String getHtmlPageList() {
			String html = "";
			
			// {블럭 처리 - 8/9}.
			if(hasPrev) {
				html += String.format("<a href='/board/list?page=%d'>이전</a>",prevPage);
			}
			
			for(int i = blockStartNo; i<=blockEndNo; i++) {
				html += String.format("<a href='/board/list?page=%d'>%d</a>&nbsp;&nbsp;",i,i);
			}
			
			//{블럭 처리 - 9/9}.
			if(hasNext) {
				html += String.format("<a href='/board/list?page=%d'>다음</a>",nextPage);
			}
			return html;
		}
}

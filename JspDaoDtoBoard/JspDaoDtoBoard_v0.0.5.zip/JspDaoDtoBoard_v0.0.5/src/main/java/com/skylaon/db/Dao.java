package com.skylaon.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Dao extends Da{

	private static StringBuilder sb = new StringBuilder();
	
	// stringbuilder를 리턴하면서 초기화해줌
	private static String toSql() {
		String sql = sb.toString();
		sb.setLength(0);
		return sql;
	}
	
	// 삭제
	public void del(String no) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		sb.append("delete from sl_board_free \n");
		sb.append("where b_no = ").append(no);
		
		pst = con.prepareStatement(toSql());
		
		int result = pst.executeUpdate();
		
		if (result == 1) {
			System.out.println("삭제가 완료되었습니다.");
		}else {
			System.out.println("삭제에 실패하였습니다.");
		}
		Da.closeConnection(con,pst);
	}
	
	// 쓰기
	public void write(Dto d) throws Exception{
		
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		sb.append("insert into sl_board_free(b_title, b_id, b_text) \n");
		sb.append("values(?, ?, ?);");
		
		pst = con.prepareStatement(toSql());
		
		int valueIndex = 1;
		
		pst.setString(valueIndex++, d.title);
		pst.setString(valueIndex++, d.id);
		pst.setString(valueIndex++, d.text);
		
		int result = pst.executeUpdate();
		if (result == 1) {
			System.out.println("등록이 완료되었습니다.");
		}else {
			System.out.println("등록에 실패하였습니다.");
		}
		super.closeConnection(con,pst);
		
	}
	
	// 읽기
	public Dto read(String no) throws Exception{
		
		Dto post = null;
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		sb.append("select * from sl_board_free \n");
		sb.append("where b_no = ").append(no);
		
		pst = con.prepareStatement(toSql());
		
		ResultSet res = pst.executeQuery();
		
		
		if(res.next()) {
			post = new Dto(res.getString("B_NO"),
					res.getString("B_TITLE"),
					res.getString("B_ID"),
					res.getString("B_DATETIME"),
					res.getString("B_HIT"),
					res.getString("B_TEXT"),
					res.getString("B_REPLY_COUNT"),
					res.getString("B_REPLY_ORI"));
		}else {
			System.out.println("시스템 오류 발생");
		}
		
		
		super.closeConnection(con, pst, res);

		return post;
	}
	
	// 리스트
	public ArrayList<Dto> list(String page) throws Exception{
		ArrayList<Dto> posts = new ArrayList<>();
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		int startIndex = ((Integer.parseInt(page))-1) * Board.LIST_AMOUNT;
		
		String sql = String.format("select * from %s limit %d,%d",
				Da.TABLE_SL_BOARD_FREE, startIndex,Board.LIST_AMOUNT);
		
		pst = con.prepareStatement(sql);
		
		ResultSet res = pst.executeQuery();
		
		while(res.next()) {
			posts.add(new Dto(
					res.getString("B_NO"),
					res.getString("B_TITLE"),
					res.getString("B_ID"),
					res.getString("B_DATETIME"),
					res.getString("B_HIT"),
					res.getString("B_TEXT"),
					res.getString("B_REPLY_COUNT"),
					res.getString("B_REPLY_ORI")
						));
		}
		super.closeConnection(con, pst, res);
		System.out.println("리스트 완료");
		return posts;
	}
	
	//수정
	public void edit(Dto d, String no) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		sb.append("update sl_board_free set b_title = ?, b_text = ? \n");
		sb.append("			where b_no = ?");
		
		pst = con.prepareStatement(toSql());
		int valueIndex = 1;
		
	
		pst.setString(valueIndex++, d.title);
		pst.setString(valueIndex++, d.text);
		pst.setString(valueIndex++, no);
		
		int result = pst.executeUpdate();
		
		if(result == 1) {
			System.out.println("수정이 완료되었습니다.");
		}else {
			System.out.println("수정에 실패하였습니다.");
		}
		super.closeConnection(con, pst);
	}
	
	public ArrayList<Dto> listSearch(String word, String page) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		ArrayList<Dto> posts = new ArrayList<Dto>();
		
		int startIndex = ((Integer.parseInt(page))-1) * 3;
		
		// 작업 필요 06.26
		sb.append("select * from sl_board_free \n");
		sb.append("where b_title like concat('%', ?, '%') limit ?, ?;");
		
		pst = con.prepareStatement(toSql());
		int valueIndex = 1;
		
		pst.setString(valueIndex++, word);
		pst.setInt(valueIndex++, startIndex);
		pst.setInt(valueIndex++, Board.LIST_AMOUNT);
		
		ResultSet res = pst.executeQuery();
		
		while(res.next()) {
			posts.add(new Dto(
					res.getString("B_NO"),
					res.getString("B_TITLE"),
					res.getString("B_ID"),
					res.getString("B_DATETIME"),
					res.getString("B_HIT"),
					res.getString("B_TEXT"),
					res.getString("B_REPLY_COUNT"),
					res.getString("B_REPLY_ORI")
					));
		}
		
		super.closeConnection(con, pst, res);
		return posts;
	}
	
	// 총 개시물 수
	public int getPostCount() throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		sb.append("select count(*) from sl_board_free;");
		
		pst = con.prepareStatement(toSql());
		ResultSet res = pst.executeQuery();
		
		int count=res.next()?res.getInt("count(*)"):0;

		super.closeConnection(con, pst, res);
		return count;
	}
	
	// 총 게시물 수<검색용>
	public int getPostCount(String word) throws Exception{
		Connection con = super.getConnection();
		PreparedStatement pst = null;
		
		String sql = String.format(
				"select count(*) from %s where b_title like '%%%s%%'"
				,Dao.TABLE_SL_BOARD_FREE,word);
		
		
		pst = con.prepareStatement(sql);
		ResultSet res = pst.executeQuery();
		
		int count=res.next()?res.getInt("count(*)"):0;

		super.closeConnection(con, pst, res);
		return count;
	}
	
	// 총 페이지 수
	public int getTotalPageCount() throws Exception{
		int count = getPostCount(); // 게시물 수
		int totalPageCount = 0;

		if(count % Board.LIST_AMOUNT == 0){		//case1. 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / Board.LIST_AMOUNT;
		}else{					//case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	// 총 페이지 수<검색>
	public int getTotalPageCount(String word) throws Exception{
		int count = getPostCount(word); // 게시물 수
		int totalPageCount = 0;

		if(count % Board.LIST_AMOUNT == 0){		//case1. 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / Board.LIST_AMOUNT;
		}else{					//case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
}












